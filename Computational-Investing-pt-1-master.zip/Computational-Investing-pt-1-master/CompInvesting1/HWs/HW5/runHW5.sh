#!/bin/bash

# author: Varad Meru
# contact: varad.meru@gmail.com
# summary: Homework 5 - Bollinger band values

python bollinger.py AAPL,GOOG,IBM,MSFT 2010,1,1 2010,12,31 20