compinvesting1-hw
=================

Homework for the "Coursera - Computational Investing 1" Course

